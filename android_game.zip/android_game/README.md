# soc-android-game

http://www.koonsolo.com/news/dewitters-gameloop/
